%% Test your visualization of rotation matrices
%
% Written by Xiaozhuo Laura Cheng, University of Pennsylvania
% For MEAM 520: Introduction to Robotics
% September 2015
% Version 1

function testR

clear
clc

%% Choose test mode first.
display('Welcome to test R!');
display('Please choose your test mode first.');
display('1. R Matrix ----> Visual Representation');
display('2. Visual Representation ----> R Matrix');
display('Your choice is: ');
test_type = input('');

% set a variable to get the student's responce from the user interface.
global reply;

% Set an offset number for the user to reach as goal.
% After that, the student can quit the practicing program using
% the designed 'Quit' button.
% Here choose contiCorrect as 5. (continuous correct answers)
quitnumber = 5;
isAbleToQuit = 0;

switch(test_type)
    %% Test:  rotation matrix to visual representation.
    case 1
        % Variables Settings:
        % isOKtoQuit: variable for if eligible to stop by quit button
        % contiCorrect: number of correct answers successively
        % total_right, total_wrong: number of right/wrong answers in total
        isOKtoQuit = 0;
        contiCorrect = 0;
        total_right = 0;
        total_wrong = 0;
        % Inertialize percentage of accuracy rate to be zero.
        percentage = 0;
        
        ifFirstLoop = 1;
        if ifFirstLoop == 0
            % Prepare for a new loop.
            set(OKbutton, 'String', 'OK', 'position', [height*0.32, height*0.426, height*0.05, height*0.05]);
            set(quit_note, 'String', ' ');
        end
        
        % Loop without 'quit' option.
        while (isOKtoQuit == 0)
            ifFirstLoop = 0;
            
            %% Create a random rotation matrix R_right.
            % Create a 3 x 3 matrix of normally distributed pseudorandom numbers.
            random_matrix = randn(3);
            
            % Decompose the random matrix using QR decomposition.
            [Q, R] = qr(random_matrix);
            
            % Create what will be our rotation matrix by manipulation of Q and R.
            R_right = Q*diag(sign(diag(R)));
            
            % Valid rotation matrices must have determinant equal to +1.
            if (det(R_right) < 0)
                R_right(:,1) = - R_right(:,1);
            end
            
            
            %% Create three random rotation matrics R_wrong.
            % Set a variable for successful settings for R matrices.
            success_numbers = 0;
            
            % Set 1 as starting index of matrix options.
            index = 1;
            
            % Create random rotation matrics until got three successfully.
            while (success_numbers < 3)
                % Use the same method to create rotation matrix.
                
                % Create a 3 x 3 matrix of normally distributed pseudorandom numbers.
                random_matrix = randn(3);
                % Decompose the random matrix using QR decomposition.
                [Q, R] = qr(random_matrix);
                % Create what will be our rotation matrix by manipulation of Q and R.
                R_new = Q*diag(sign(diag(R)));
                % Valid rotation matrices must have determinant equal to +1.
                if (det(R_new) < 0)
                    R_new(:,1) = - R_new(:,1);
                end
                
                % Include the R_new in R_wrong sequences.
                R_wrong{index} = R_new;
                
                % Judge if this is a successful creating. Here the criteria
                % is at least two elemnts is R matrix has difference larger
                % than 0.4.
                % If not, the same index will be replaced and judged again.
                if max(abs(R_new - R_right)) > 0.4
                    success_numbers = success_numbers + 1;
                    index = index + 1;
                end
                
            end
            
            
            %% Write out the rotation matrix
            % Open figure 1 and clear it.
            figure(1)
            clf
            
            % Get the screen size and set relatively suitable window size.
            screen_size = get(groot,'Screensize');
            height = screen_size(4);
            set(gcf,'position',[height*0.05, height*0.08, height*0.85, height*0.85])
            
            % Choose the upper left subplot in a 2 x 2 matrix of subplots.
            subplot(2,2,1);
            
            % Get the position of this subplot within the window and change the
            % fontsize to a larger value to facilitate viewing.
            fontsize = 16;
            set(gca,'fontsize',fontsize);
            axis([0 1 0 1]);
            
            % Write the name of the matrix with an equal sign.
            text(-0.15, 0.65, 'R^0_1 =', 'fontsize', fontsize);
            
            % Display the values of the matrix itself.
            text(0.0, 0.65, num2str(R_right, '%0.4f  '), 'fontsize', fontsize)
            
            % Turn the axes off so we see only the matrix against the gray background.
            axis off
            
            % Write the name of the matrix with an equal sign.
            text(-0.31, 0.915, 'Choose the corresponding visualize representation ', 'fontsize', fontsize);
            text(-0.31, 0.85, 'for the following Rotation matrix R : ', 'fontsize', fontsize);
            
            % Write the choice guide.
            text(-0.31, 0.45, 'Your Answer is : ', 'fontsize', fontsize);
            
            % Potential text space to tell the user can quit this program
            % using Quit button later.
            quit_note = text(-0.31, -0.1, ' ', 'fontsize', fontsize, 'Color', 'w');
            
            % Potential text space to tell the user about correctness and
            % correct answer if wrong.
            result_report = text(-0.31, 0.1, ' ', 'fontsize', 16, 'Color', 'r');
            
            % Potential text space to guide the user keep practicing.
            ok_continue = text(-0.31, 0.02, ' ', 'fontsize', 16, 'Color', 'k');
            
            % Create three pushbuttons to get the reply from the user.
            % The tag shows the corresponding subplot index here.
            buttonA = uicontrol('Style', 'pushbutton', ...
                'HandleVisibility','off', 'string', 'A', 'tag', '2',...
                'fontsize', fontsize, ...
                'callback', @PushA,...
                'position', [height*0.04, height*0.57, height*0.06, height*0.04]);
            buttonB = uicontrol('Style', 'pushbutton', ...
                'HandleVisibility','off', 'string', 'B', 'tag', '3',...
                'fontsize', fontsize, ...
                'callback', @PushB,...
                'position', [height*0.11, height*0.57, height*0.06, height*0.04]);
            buttonC = uicontrol('Style', 'pushbutton',...
                'HandleVisibility','off', 'string', 'C', 'tag', '4',...
                'fontsize', fontsize, ...
                'callback', @PushC,...
                'position', [height*0.18, height*0.57, height*0.06, height*0.04]);
            
            % OK button to make sure the choice will not change further.
            % The callback function PushOK is designed to judge the result.
            OKbutton = uicontrol('Style','pushButton',...
                'string', 'OK', 'fontweight', 'bold',...
                'Enable', 'on',...
                'fontsize', fontsize, ...
                'callback', @PushOK, ...
                'position',[height*0.25, height*0.565, height*0.05, height*0.05]);
            
            % Write the relative statistics report here, including correct
            % numbers, wrong numbers, and then computing accuracy rate.
            text(-0.32, 1.14, '\it Correct:  ', 'fontsize', 15, 'Color', 'b');
            text(0.16, 1.14, '\it Wrong:  ', 'fontsize', 15, 'Color', 'b');
            text(0.60, 1.14, '\it Accuracy Rate:  ', 'fontsize', 15, 'Color', 'b');
            sta1 = text(-0.07, 1.14, num2str(total_right, '%0.0f'), 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
            sta2 = text(0.40, 1.14, num2str(total_wrong, '%0.0f'), 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
            sta3 = text(1.05, 1.14, [num2str(percentage, '%0.2f'),' %'], 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
            
            
            
            %% Plot the three wrong answers in order.
            
            % Here I choose to plot all three wrong answers in subfigures
            % and then replace one of them in random.
            
            % Loop through each of the three wrong answers.
            for index = 2:4
                % Set the position and font size.
                subplot(2,2,index);
                switch (index)
                    case 2
                        set(gca,'position',[0.5 0.5 0.45 0.45], 'fontsize',fontsize);
                    case 3
                        set(gca,'position',[0.05 0.05 0.45 0.45], 'fontsize',fontsize);
                    case 4
                        set(gca,'position',[0.5 0.05 0.45 0.45], 'fontsize',fontsize);
                end
                
                % Plot the origin as a black circle.
                plot3(0,0,0,'ko');
                
                % Turn on the grid.
                grid on
                
                % Choose a display mode that makes one unit display the same in all
                % directions and keeps the plot the same size as you rotate it.
                axis vis3d
                
                % Plot the base frame, frame zero, in black; it's an identity matrix.
                c0 = [0 0 0];
                % Color of frame 0.
                plotCoordinateFrame(eye(3),0,c0);
                
                % Plot the random rotation matrix, frame one, in darkened
                % red. (wrong answer)
                c1 = [.8 0 0];
                plotCoordinateFrame(R_wrong{index-1},1,c1);
                
                % Set the axis limits and label the axes.
                axis(1.25 * [-1 1 -1 1 -1 1])
                set(gca,'xtick',-1:.5:1,'ytick',-1:.5:1,'ztick',-1:.5:1)
                xlabel('X')
                ylabel('Y')
                zlabel('Z')
                
                % Label the option with 'A', 'B', or 'C'.
                switch (index)
                    case 2
                        t2 = title('A','fontsize',25,'Color','b');
                        set(t2,'Position',[-0.5, -0.5, -1.2]);
                    case 3
                        t3 = title('B','fontsize',25,'Color','b');
                        set(t3,'Position',[-0.5, -0.5, -1.2]);
                    case 4
                        t4 = title('C','fontsize',25,'Color','b');
                        set(t4,'Position',[-0.5, -0.5, -1.2]);
                end
                
            end
            
            
            %% Replace one by the right visual representation.
            
            % Choose the correspong subplot (index is answer), and set the font size.
            % Set indexes for right and wrong answers.
            answer = randi([2 4]);
            subplot(2,2,answer,'replace');
            switch (answer)
                case 2
                    set(gca,'position',[0.5 0.5 0.45 0.45], 'fontsize',fontsize);
                case 3
                    set(gca,'position',[0.05 0.05 0.45 0.45], 'fontsize',fontsize);
                case 4
                    set(gca,'position',[0.5 0.05 0.45 0.45], 'fontsize',fontsize);
            end
            
            % Plot the origin as a black circle.
            plot3(0,0,0,'ko');
            
            % Turn on the grid.
            grid on
            
            % Choose a display mode that makes one unit display the same in all
            % directions and keeps the plot the same size as you rotate it.
            axis vis3d
            
            % Plot the base frame, frame zero, in black; it's an identity matrix.
            c0 = [0 0 0];
            % Color of frame 0.
            plotCoordinateFrame(eye(3),0,c0);
            
            % Plot the random rotation matrix, frame one, in darkened red.
            c1 = [.8 0 0];
            plotCoordinateFrame(R_right,1,c1);
            
            % Set the axis limits and label the axes.
            axis(1.25 * [-1 1 -1 1 -1 1])
            set(gca,'xtick',-1:.5:1,'ytick',-1:.5:1,'ztick',-1:.5:1)
            xlabel('X')
            ylabel('Y')
            zlabel('Z')
            
            % Label again since the whole subfigure is replaced.
            switch (answer)
                case 2
                    t2 = title('A','fontsize',25,'Color','b');
                    set(t2,'Position',[-0.5, -0.5, -1.2]);
                case 3
                    t3 = title('B','fontsize',25,'Color','b');
                    set(t3,'Position',[-0.5, -0.5, -1.2]);
                case 4
                    t4 = title('C','fontsize',25,'Color','b');
                    set(t4,'Position',[-0.5, -0.5, -1.2]);
            end
            
            
            %% Statistics of right, wrong answers' numbers and accuracy rate.
            % Wait until a choice be done.
            uiwait(gcf);
            
            if (reply == answer)
                % If answered correctly
                total_right = total_right + 1;
                contiCorrect = contiCorrect + 1;
                
                % Post result report here.
                set(result_report, 'string', 'Congratulations! You got the right answer:) ');
                
                % Post guide to click Continue button to keep going.
                set(OKbutton, 'String', 'Continue', 'position', [height*0.25, height*0.565, height*0.09, height*0.05]);
                set(ok_continue, 'string', 'Click Continue button if you want to go on practicing. ');
                
                % Change the buttons' colors.
                set(buttonA, 'ForegroundColor', 'w');
                set(buttonB, 'ForegroundColor', 'w');
                set(buttonC, 'ForegroundColor', 'w');
                switch(reply)
                    case 2
                        set(buttonA, 'ForegroundColor', 'g');
                    case 3
                        set(buttonB, 'ForegroundColor', 'g');
                    case 4
                        set(buttonC, 'ForegroundColor', 'g');
                end
                
            else
                % If answered uncorrectly
                total_wrong = total_wrong + 1;
                contiCorrect = 0;
                isAbleToQuit = 0;
                
                % Post result report here.
                switch answer
                    case 2
                        ans_str = 'A';
                    case 3
                        ans_str = 'B';
                    case 4
                        ans_str = 'C';
                end
                set(result_report, 'string', ['Sorry, you are Wrong! The right answer is ', ans_str, '.']);
                
                % Post guide to click Continue button to keep going.
                set(OKbutton, 'String', 'Continue', 'position', [height*0.25, height*0.565, height*0.09, height*0.05]);
                set(ok_continue, 'string', 'Click Continue button if you want to go on practicing. ');
                
                % Change the buttons' colors.
                switch(answer)
                    case 2
                        set(buttonA, 'ForegroundColor', 'g');
                    case 3
                        set(buttonB, 'ForegroundColor', 'g');
                    case 4
                        set(buttonC, 'ForegroundColor', 'g');
                end
            end
            
            % Change the showing of statistics on user interface.
            percentage = total_right / (total_right + total_wrong) * 100;
            set(sta1, 'string', num2str(total_right, '%0.0f'));
            set(sta2, 'string', num2str(total_wrong, '%0.0f'));
            set(sta3, 'string', [num2str(percentage, '%0.1f'),' %']);
            
            % Set an offset number for the user to reach as goal.
            % After that, the student can quit the practicing program using
            % the designed 'Quit' button.
            % Here choose contiCorrect as 5. (continuous correct answers)
            if (contiCorrect == quitnumber) || (isAbleToQuit == 1)
                isAbleToQuit = 1;
                subplot(2,2,1);
                
                % Add a Quit button here.
                Quitbutton = uicontrol('Style','pushButton',...
                    'string', 'Quit', 'fontweight', 'bold',...
                    'Enable', 'on',...
                    'fontsize', fontsize, ...
                    'callback', @PushQuit, ...
                    'position',[height*0.35, height*0.565, height*0.05, height*0.05]);
                
                % Add a reminder about Quit option
                set(quit_note, 'String', {'Successive correct choices!', 'Click Quit button to stop practicing at any time.'},'color','m');
            end
            
            uiwait(gcf);
            
        end
        
        
    case 2
        %% Test:  rotation matrix to visual representation.
        % Variables Settings:
        % isOKtoQuit: variable for if eligible to stop by quit button
        % contiCorrect: number of correct answers successively
        % total_right, total_wrong: number of right/wrong answers in total
        % Inertialize percentage of accuracy rate to be zero.
        isOKtoQuit = 0;
        contiCorrect = 0;
        total_right = 0;
        total_wrong = 0;
        percentage = 0;
        ifFirstLoop = 1;
        
        if ifFirstLoop == 0
            % Prepare for a new loop.
            set(OKbutton, 'String', 'OK', 'position', [height*0.32, height*0.426, height*0.05, height*0.05]);
            set(quit_note, 'String', ' ');
        end
        
        % Loop without 'quit' option.
        while (isOKtoQuit == 0)
            ifFirstLoop = 0;
            
            %% Create a random rotation matrix R_right.
            % Create a 3 x 3 matrix of normally distributed pseudorandom numbers.
            random_matrix = randn(3);
            
            % Decompose the random matrix using QR decomposition.
            [Q, R] = qr(random_matrix);
            
            % Create what will be our rotation matrix by manipulation of Q and R.
            R_right = Q*diag(sign(diag(R)));
            
            % Valid rotation matrices must have determinant equal to +1.
            if (det(R_right) < 0)
                R_right(:,1) = - R_right(:,1);
            end
            
            
            %% Create three random rotation matrics R_wrong.
            % Set a variable for successful settings for R matrices.
            success_numbers = 0;
            
            % Set 1 as starting index of matrix options.
            index = 1;
            
            % Create random rotation matrics until got three successfully.
            while (success_numbers < 3)
                % Use the same method to create rotation matrix.
                
                % Create a 3 x 3 matrix of normally distributed pseudorandom numbers.
                random_matrix = randn(3);
                % Decompose the random matrix using QR decomposition.
                [Q, R] = qr(random_matrix);
                % Create what will be our rotation matrix by manipulation of Q and R.
                R_new = Q*diag(sign(diag(R)));
                % Valid rotation matrices must have determinant equal to +1.
                if (det(R_new) < 0)
                    R_new(:,1) = - R_new(:,1);
                end
                
                % Include the R_new in R_wrong sequences.
                R_wrong{index} = R_new;
                
                % Judge if this is a successful creating. Here the criteria
                % is at least two elemnts is R matrix has difference larger
                % than 0.4.
                % If not, the same index will be replaced and judged again.
                if max(abs(R_new - R_right)) > 0.4
                    success_numbers = success_numbers + 1;
                    index = index + 1;
                end
                
            end
            
            %% Plot out the rotation matrix
            % Open figure 1 and clear it.
            figure(1)
            clf
            
            % Get the screen size and set relatively suitable window size.
            screen_size = get(groot,'Screensize');
            height = screen_size(4);
            set(gcf,'position',[height*0.05, height*0.08, height*0.85, height*0.85])
            
            % Choose the upper left subplot in a 2 x 2 matrix of subplots.
            subplot(2,2,1);
            
            % Get the position of this subplot within the window and change the
            % fontsize to a larger value to facilitate viewing.
            fontsize = 16;
            set(gca,'fontsize',fontsize);
            
            % Plot the origin as a black circle.
            plot3(0,0,0,'ko');
            
            % Turn on the grid.
            grid on
            
            % Choose a display mode that makes one unit display the same in all
            % directions and keeps the plot the same size as you rotate it.
            axis vis3d
            
            % Plot the base frame, frame zero, in black; it's an identity matrix.
            c0 = [0 0 0];
            % Color of frame 0.
            plotCoordinateFrame(eye(3),0,c0);
            
            % Plot the random rotation matrix, frame one, in darkened
            % red. (wrong answer)
            c1 = [.8 0 0];
            plotCoordinateFrame(R_right,1,c1);
            
            % Set the axis limits and label the axes.
            axis(1.25 * [-1 1 -1 1 -1 1])
            set(gca,'xtick',-1:.5:1,'ytick',-1:.5:1,'ztick',-1:.5:1)
            xlabel('X')
            ylabel('Y')
            zlabel('Z')
            
            %% Write out three wrong answers in order.
            
            % Here I choose to write out all three wrong answers in subfigures
            % and then replace one of them in random.
            
            % Loop through each of the three wrong answers.
            for index = 2:4
                % Set the position and font size.
                subplot(2,2,index);
                switch (index)
                    case 2
                        set(gca,'position',[0.5 0.5 0.45 0.45], 'fontsize',fontsize);
                    case 3
                        set(gca,'position',[0.05 0.05 0.45 0.45], 'fontsize',fontsize);
                    case 4
                        set(gca,'position',[0.5 0.05 0.45 0.45], 'fontsize',fontsize);
                end
                
                set(gca,'fontsize',fontsize);
                
                axis([0 1 0 1]);
                
                % Write the name of the matrix with an equal sign.
                % Display the values of the matrix itself.
                if index == 2
                    text(0.1, 0.2, 'R^0_1 =', 'fontsize', fontsize);
                    text(0.25, 0.2, num2str(R_wrong{index-1}, '%0.4f  '), 'fontsize', fontsize)
                else
                    text(0.1, 0.5, 'R^0_1 =', 'fontsize', fontsize);
                    text(0.25, 0.5, num2str(R_wrong{index-1}, '%0.4f  '), 'fontsize', fontsize)
                end
                
                % Turn the axes off so we see only the matrix against the gray background.
                axis off
                
                % Label the option with 'A', 'B', or 'C'.
                switch (index)
                    case 2
                        t2 = title('A','fontsize',25,'Color','b');
                        set(t2,'Position',[0.1, 0.3]);
                    case 3
                        t3 = title('B','fontsize',25,'Color','b');
                        set(t3,'Position',[0.1, 0.6]);
                    case 4
                        t4 = title('C','fontsize',25,'Color','b');
                        set(t4,'Position',[0.1, 0.6]);
                end
                
                if index == 2
                    
                    % Write the name of the matrix with an equal sign.
                    text(-1.06, 0.998, 'Choose the corresponding R matrix for the following ', 'fontsize', fontsize);
                    text(-1.05, 0.94, 'visual representation : ', 'fontsize', fontsize);
                    
                    % Write the choice guide.
                    text(-1, 0.15, 'Your Answer is : ', 'fontsize', fontsize);
                    
                    % Potential text space to tell the user can quit this program
                    % using Quit button later.
                    quit_note = text(-1, -0.23, ' ', 'fontsize', fontsize);
                    
                    % Potential text space to tell the user about correctness and
                    % correct answer if wrong.
                    result_report = text(-1, -0.05, ' ', 'fontsize', 16, 'Color', 'r');
                    
                    % Potential text space to guide the user keep practicing.
                    ok_continue = text(-1, -0.11, ' ', 'fontsize', 16, 'Color', 'k');
                    
                    % Create three pushbuttons to get the reply from the user.
                    % The tag shows the corresponding subplot index here.
                    buttonA = uicontrol('Style', 'pushbutton', ...
                        'HandleVisibility','off', 'string', 'A', 'tag', '2',...
                        'fontsize', fontsize, ...
                        'callback', @PushA,...
                        'position', [height*0.11, height*0.43, height*0.06, height*0.04]);
                    buttonB = uicontrol('Style', 'pushbutton', ...
                        'HandleVisibility','off', 'string', 'B', 'tag', '3',...
                        'fontsize', fontsize, ...
                        'callback', @PushB,...
                        'position', [height*0.18, height*0.43, height*0.06, height*0.04]);
                    buttonC = uicontrol('Style', 'pushbutton',...
                        'HandleVisibility','off', 'string', 'C', 'tag', '4',...
                        'fontsize', fontsize, ...
                        'callback', @PushC,...
                        'position', [height*0.25, height*0.43, height*0.06, height*0.04]);
                    
                    % OK button to make sure the choice will not change further.
                    % The callback function PushOK is designed to judge the result.
                    OKbutton = uicontrol('Style','pushButton',...
                        'string', 'OK', 'fontweight', 'bold',...
                        'Enable', 'on',...
                        'fontsize', fontsize, ...
                        'callback', @PushOK, ...
                        'position',[height*0.32, height*0.426, height*0.05, height*0.05]);
                    
                    % Write the relative statistics report here, including correct
                    % numbers, wrong numbers, and then computing accuracy rate.
                    text(0.1, 1, '\it Correct:  ', 'fontsize', 15, 'Color', 'b');
                    text(0.35, 1, '\it Wrong:  ', 'fontsize', 15, 'Color', 'b');
                    text(0.6, 1, '\it Accuracy Rate:  ', 'fontsize', 15, 'Color', 'b');
                    sta1 = text(0.28, 1, num2str(total_right, '%0.0f'), 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
                    sta2 = text(0.52, 1, num2str(total_wrong, '%0.0f'), 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
                    sta3 = text(0.92, 1, [num2str(percentage, '%0.2f'),' %'], 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
                    
                end
                
            end
            
            %% Replace one by the right visual representation.
            
            % Choose the correspong subplot (index is answer), and set the font size.
            % Set indexes for right and wrong answers.
            answer = randi([2 4]);
            subplot(2,2,answer,'replace');
            switch (answer)
                case 2
                    set(gca,'position',[0.5 0.5 0.45 0.45], 'fontsize',fontsize);
                case 3
                    set(gca,'position',[0.05 0.05 0.45 0.45], 'fontsize',fontsize);
                case 4
                    set(gca,'position',[0.5 0.05 0.45 0.45], 'fontsize',fontsize);
            end
            
            set(gca,'fontsize',fontsize);
            
            axis([0 1 0 1]);
            
            % Write the name of the matrix with an equal sign.
            % Display the values of the matrix itself.
            if answer == 2
                text(0.1, 0.2, 'R^0_1 =', 'fontsize', fontsize);
                text(0.25, 0.2, num2str(R_right, '%0.4f  '), 'fontsize', fontsize)
            else
                text(0.1, 0.5, 'R^0_1 =', 'fontsize', fontsize);
                text(0.25, 0.5, num2str(R_right, '%0.4f  '), 'fontsize', fontsize)
            end
            
            % Turn the axes off so we see only the matrix against the gray background.
            axis off
            
            % Label the option with 'A', 'B', or 'C'.
            switch (answer)
                case 2
                    t2 = title('A','fontsize',25,'Color','b');
                    set(t2,'Position',[0.1, 0.3]);
                case 3
                    t3 = title('B','fontsize',25,'Color','b');
                    set(t3,'Position',[0.1, 0.6]);
                case 4
                    t4 = title('C','fontsize',25,'Color','b');
                    set(t4,'Position',[0.1, 0.6]);
            end
            
            if answer == 2
                
                % Write the name of the matrix with an equal sign.
                text(-1.06, 0.998, 'Choose the corresponding R matrix for the following ', 'fontsize', fontsize);
                text(-1.05, 0.94, 'visual representation : ', 'fontsize', fontsize);
                
                % Write the choice guide.
                text(-1, 0.15, 'Your Answer is : ', 'fontsize', fontsize);
                
                % Potential text space to tell the user can quit this program
                % using Quit button later.
                quit_note = text(-1, -0.23, ' ', 'fontsize', fontsize);
                
                % Potential text space to tell the user about correctness and
                % correct answer if wrong.
                result_report = text(-1, -0.05, ' ', 'fontsize', 16, 'Color', 'r');
                
                % Potential text space to guide the user keep practicing.
                ok_continue = text(-1, -0.11, ' ', 'fontsize', 16, 'Color', 'k');
                
                % Create three pushbuttons to get the reply from the user.
                % The tag shows the corresponding subplot index here.
                buttonA = uicontrol('Style', 'pushbutton', ...
                    'HandleVisibility','off', 'string', 'A', 'tag', '2',...
                    'fontsize', fontsize, ...
                    'callback', @PushA,...
                    'position', [height*0.11, height*0.43, height*0.06, height*0.04]);
                buttonB = uicontrol('Style', 'pushbutton', ...
                    'HandleVisibility','off', 'string', 'B', 'tag', '3',...
                    'fontsize', fontsize, ...
                    'callback', @PushB,...
                    'position', [height*0.18, height*0.43, height*0.06, height*0.04]);
                buttonC = uicontrol('Style', 'pushbutton',...
                    'HandleVisibility','off', 'string', 'C', 'tag', '4',...
                    'fontsize', fontsize, ...
                    'callback', @PushC,...
                    'position', [height*0.25, height*0.43, height*0.06, height*0.04]);
                
                % OK button to make sure the choice will not change further.
                % The callback function PushOK is designed to judge the result.
                OKbutton = uicontrol('Style','pushButton',...
                    'string', 'OK', 'fontweight', 'bold',...
                    'Enable', 'on',...
                    'fontsize', fontsize, ...
                    'callback', @PushOK, ...
                    'position',[height*0.32, height*0.426, height*0.05, height*0.05]);
                
                % Write the relative statistics report here, including correct
                % numbers, wrong numbers, and then computing accuracy rate.
                text(0.1, 1, '\it Correct:  ', 'fontsize', 15, 'Color', 'b');
                text(0.35, 1, '\it Wrong:  ', 'fontsize', 15, 'Color', 'b');
                text(0.6, 1, '\it Accuracy Rate:  ', 'fontsize', 15, 'Color', 'b');
                sta1 = text(0.28, 1, num2str(total_right, '%0.0f'), 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
                sta2 = text(0.52, 1, num2str(total_wrong, '%0.0f'), 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
                sta3 = text(0.92, 1, [num2str(percentage, '%0.2f'),' %'], 'fontsize', 15, 'Color', 'r', 'FontAngle', 'italic');
                
            end
            
            %% Statistics of right, wrong answers' numbers and accuracy rate.
            % Wait until a choice be done.
            uiwait(gcf);
            
            if (reply == answer)
                % If answered correctly
                total_right = total_right + 1;
                contiCorrect = contiCorrect + 1;
                
                % Post result report here.
                set(result_report, 'string', 'Congratulations! You got the right answer:) ');
                
                % Post guide to click Continue button to keep going.
                set(OKbutton, 'String', 'Continue', 'position', [height*0.32, height*0.426, height*0.09, height*0.05]);
                set(ok_continue, 'string', 'Click Continue button if you want to continue practicing. ');
                
                % Change the buttons' colors.
                set(buttonA, 'ForegroundColor', 'w');
                set(buttonB, 'ForegroundColor', 'w');
                set(buttonC, 'ForegroundColor', 'w');
                switch(reply)
                    case 2
                        set(buttonA, 'ForegroundColor', 'g');
                    case 3
                        set(buttonB, 'ForegroundColor', 'g');
                    case 4
                        set(buttonC, 'ForegroundColor', 'g');
                end
                
            else
                % If answered uncorrectly
                total_wrong = total_wrong + 1;
                contiCorrect = 0;
                isAbleToQuit = 0;
                
                % Post result report here.
                switch answer
                    case 2
                        ans_str = 'A';
                    case 3
                        ans_str = 'B';
                    case 4
                        ans_str = 'C';
                end
                set(result_report, 'string', ['Sorry, you are Wrong! The right answer is ', ans_str, '.']);
                
                % Post guide to click Continue button to keep going.
                set(OKbutton, 'String', 'Continue', 'position', [height*0.32, height*0.426, height*0.09, height*0.05]);
                set(ok_continue, 'string', 'Click Continue button if you want to go on practicing. ');
                
                % Change the buttons' colors.
                switch(answer)
                    case 2
                        set(buttonA, 'ForegroundColor', 'g');
                    case 3
                        set(buttonB, 'ForegroundColor', 'g');
                    case 4
                        set(buttonC, 'ForegroundColor', 'g');
                end
            end
            
            % Change the showing of statistics on user interface.
            percentage = total_right / (total_right + total_wrong) * 100;
            set(sta1, 'string', num2str(total_right, '%0.0f'));
            set(sta2, 'string', num2str(total_wrong, '%0.0f'));
            set(sta3, 'string', [num2str(percentage, '%0.1f'),' %']);
            
            % Set an offset number for the user to reach as goal.
            % After that, the student can quit the practicing program using
            % the designed 'Quit' button.
            % Here choose contiCorrect as 5. (continuous correct answers)
            if (contiCorrect == quitnumber) || (isAbleToQuit == 1)
                isAbleToQuit = 1;
                subplot(2,2,1);
                
                % Add a Quit button here.
                Quitbutton = uicontrol('Style','pushButton',...
                    'string', 'Quit', 'fontweight', 'bold',...
                    'Enable', 'on',...
                    'fontsize', fontsize, ...
                    'callback', @PushQuit, ...
                    'position',[height*0.42, height*0.426, height*0.05, height*0.05]);
                
                % Add a reminder about Quit option
                set(quit_note, 'String', {'Successive correct choices!', 'Click Quit button to stop practicing at any time.'},'color','m');
            end
            
            uiwait(gcf);
            
        end
        
        
end

% Callback functions for buttons.
    function PushA(~,~)
        reply = 2;
        set(buttonA, 'ForegroundColor', 'r');
        set(buttonB, 'ForegroundColor', 'k');
        set(buttonC, 'ForegroundColor', 'k');
    end

    function PushB(~,~)
        reply = 3;
        set(buttonA, 'ForegroundColor', 'k');
        set(buttonB, 'ForegroundColor', 'r');
        set(buttonC, 'ForegroundColor', 'k');
    end

    function PushC(~,~)
        reply = 4;
        set(buttonA, 'ForegroundColor', 'k');
        set(buttonB, 'ForegroundColor', 'k');
        set(buttonC, 'ForegroundColor', 'r');
    end

% To start the new loop.
    function PushOK(~,~)
        uiresume(gcf);
    end

% To end the biggest loop and quit the window.
    function PushQuit(~,~)
        isOKtoQuit = 1;
        close
    end

end

